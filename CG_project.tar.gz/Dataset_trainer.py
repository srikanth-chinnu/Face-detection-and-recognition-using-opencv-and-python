#####################################
#######  DATASET TRAINING     #######
#####################################

#Note: Python uses numpy arrays for face detection and recognition

#For porting image to a location
import os

#For using existing CascadeClassifiers we need cv2
import cv2

#for numpy arrays creation we need numpy
import numpy as np

#Importing image module for converting image
from PIL import Image

# Loading default recognizer tool
recognizer = cv2.createLBPHFaceRecognizer();

#location of where our training set images located
path = 'dataSet'

def getImageWithID(path):

    #Choosing every image in the dataset
    imagePaths = [os.path.join(path,f) for f in os.listdir(path)]

    # Contains list of faces
    faces = []

    # Contains list of ids of every image
    IDs = []


    for imagePath in imagePaths:

        #Converting every image format into NUMPY ARRAY
        faceImg = Image.open(imagePath).convert('L')

        #Normalization
        faceNp = np.array(faceImg,'uint8')

        #Extracting ID of image
        ID = int(os.path.split(imagePath)[-1].split('.')[1])

        #appending numpy array for training
        faces.append(faceNp)

        #appending IDs for recognizing
        IDs.append(ID)

        #showing each image with window name training
        cv2.imshow("training",faceNp)
        cv2.waitKey(10)

    #returning all the image numpy arrays
    return np.array(IDs), faces

#calling the function to get the numpy arrays
Ids, faces = getImageWithID(path)

#training the recognizer
recognizer.train(faces,Ids)

#saving the data as training.yml
recognizer.save('recognizer/training.yml')
cv2.destroyAllWindows()
