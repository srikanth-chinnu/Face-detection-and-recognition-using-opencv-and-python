##################################################################
#######  DETECTION AND RECOGNITION OF FACES IN A VIDEO     #######
##################################################################

#Note: Python uses numpy arrays for face detection and recognition

#for numpy arrays creation we need numpy
import numpy as np

#For using existing CascadeClassifiers we need cv2
import cv2

#Loading face DETECTION haarcascade file
face_cascade = cv2.CascadeClassifier('haarcascade_frontalface_default1.xml')

# Web Video capture
cap = cv2.VideoCapture(0)

# Loading default recognizer tool
rec = cv2.createLBPHFaceRecognizer();

# Loading face RECOGNITION dataSet
rec.load("recognizer/training.yml")

# To find a particular person
id = 0

# Display font on the screen
font=cv2.cv.InitFont(cv2.cv.CV_FONT_HERSHEY_COMPLEX_SMALL,5,1,0,4)

while(1):

    #Capturing image
    ret, img = cap.read()

    #Converting captured image to its gray scale
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

    # DETECTION of face and identifying constraints like x,y,w,h
    faces = face_cascade.detectMultiScale(gray, 1.2, 5)

    for (x,y,w,h) in faces:

        #showing a rectangular box after DETECTION
        cv2.rectangle(img,(x,y),(x+w,y+h),(255,0,0),2)

        # Prediction or RECOGNITION of face
        id,conf = rec.predict(gray[y:y+h,x:x+w])

        # Printing the name of the PREDICTION
        cv2.cv.PutText(cv2.cv.fromarray(img),str(id),(x,y+h),font,255)

    # Displaying the image
    cv2.imshow("img",img)

    # Setting the name for the window as img
    cv2.namedWindow("img",cv2.WND_PROP_FULLSCREEN)

    # Setting property for the img to be displayed
    cv2.setWindowProperty("img",cv2.WND_PROP_FULLSCREEN,0)

    if(cv2.waitKey(1)==ord('q')):
        break

cap.release()
cv2.destroyAllWindows()
