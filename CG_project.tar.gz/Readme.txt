1. Construct a dataset using 'face_dataset_image.py' or 'face_dataset_video.py'

2.Train with the dataset using 'Dataset_trainer.py'

3.Recognition will be done using 'face_recognizer_image.py' or 'face_recognizer_video.py'
