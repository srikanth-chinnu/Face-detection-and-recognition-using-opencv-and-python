##################################################################
############  DATASET CREATION USING VIDEO CAPTURE    ############
##################################################################

#Note: Python uses numpy arrays for face detection and recognition

# for numpy arrays creation we need numpy
import numpy as np

# For using existing CascadeClassifiers we need cv2
import cv2

# Loading face DETECTION haarcascade file
face_cascade = cv2.CascadeClassifier('haarcascade_frontalface_default.xml')

# Web Video capture
cap = cv2.VideoCapture(0)

# User input
id = raw_input('enter user id')

# Indicates the sequence of image of a particular ID
seqNum = 0

while 1:

    #Capturing image
    ret, img = cap.read()

    #Converting captured image to its gray scale
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

    # DETECTION of face and identifying constraints like x,y,w,h
    faces = face_cascade.detectMultiScale(gray, 1.2, 5)

    for (x,y,w,h) in faces:

        # Incrementing SeqNum for assigning unique SeqNum for a particular ID
        seqNum += 1

        # Naming the each face
        cv2.imwrite("dataSet/User."+str(id)+"."+str(seqNum)+".jpg",gray[y:y+h,x:x+w])

        #Cropping and drawing a rectangular box after DETECTION
        cv2.rectangle(img,(x,y),(x+w,y+h),(255,0,0),2)
        cv2.waitKey(100)

    # Displaying the image
    cv2.imshow('img',img)

    cv2.waitKey(1)

    # Limiting the number of images to be taken to 21
    if(seqNum>20):
        break

cap.release()
cv2.destroyAllWindows()
